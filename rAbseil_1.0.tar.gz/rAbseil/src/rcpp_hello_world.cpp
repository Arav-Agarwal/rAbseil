
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double rcpp_hello_world() {
    return 1.0;
}
