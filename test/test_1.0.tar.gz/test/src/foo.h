
int foo();
